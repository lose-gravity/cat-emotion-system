// comment removed
// comment removed
$fn = 60;
W = 3;              // comment removed

module front_wall() {
    difference() {
        cube([120, W, 60]);                       // comment removed
        translate([45, -1, 0]) cube([30, W + 2, 25]);  // comment removed
    }
}

module side_wall() {
    cube([W, 80, 60]);                            // comment removed
}

module dispenser_disc() {
    // horizontal notched disc, vertical shaft, at hopper floor
    translate([60, 10, 1.5])
        rotate([0, 0, 0])
            difference() {
                cylinder(d = 36, h = W);
                // notch (wedge opening toward the chute)
                rotate([0, 0, 90])
                    translate([-25, 0, -1])
                        cube([50, 36, W + 2]);
            }
}

module servo_shaft() {
    // shaft through the floor hole
    translate([60, 10, -8]) cylinder(d = 5, h = 12);
}
module servo_mock() {
    translate([47, 4, -22]) cube([26, 12, 22]);   // servo under the floor
}

module grain(x, y, z) {
    translate([x, y, z]) sphere(d = 6);
}



module assembled() {
    front_wall();
    translate([0, 77, 0]) cube([120, W, 60]);     // comment removed
    side_wall();                                   // comment removed
    translate([117, 0, 0]) side_wall();            // comment removed
    translate([0, W, 0]) cube([120, 74, W]);       // comment removed
    dispenser_disc();
    servo_mock();
    // comment removed
    grain(35, 15, 6);
    grain(50, 20, 6);
    grain(65, 18, 6);
    grain(85, 25, 6);
}

assembled();
